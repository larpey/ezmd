Season bundle: the tarball holds the report and the site table.
