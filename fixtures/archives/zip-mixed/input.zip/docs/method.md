# Method

## Counting

Count from the same hide every morning.

| Step | Action |
|---|---|
| 1 | Arrive before dawn |
| 2 | Count for 20 minutes |
