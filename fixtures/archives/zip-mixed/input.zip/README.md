# Survey Kit

This archive holds the field survey kit.

- `notes.txt`: raw notes
- `docs/method.md`: the method
