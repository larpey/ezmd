from stockroom.inventory import Inventory, Item


def test_low_stock() -> None:
    inv = Inventory()
    inv.add(Item("A-1", "Widget", 1))
    assert [i.sku for i in inv.low_stock()] == ['A-1']
