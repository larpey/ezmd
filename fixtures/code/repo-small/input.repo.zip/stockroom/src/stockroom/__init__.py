"""stockroom package."""

