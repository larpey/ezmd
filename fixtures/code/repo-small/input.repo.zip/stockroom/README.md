# stockroom

A small inventory service used as an ezmd repo-pack fixture.

Run `python -m stockroom` to print items that need reordering.
