"""tidepool entry point."""
import os

TOKEN = os.environ["INGEST_TOKEN"]  # read at runtime, nothing to redact


def main() -> None:
    print("ingest ready")
