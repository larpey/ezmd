// client.js: upstream HTTP client.
export async function fetchReadings(base) {
  const res = await fetch(base + '/readings', {
    headers: { Authorization: 'Bearer 1c3a4713a61ed9d744faeaf3f76d085b' },
  });
  return res.json();
}
export const MAX_RETRIES = 3;
