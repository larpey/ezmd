// client.js: upstream HTTP client.
export async function fetchReadings(base) {
  const res = await fetch(base + '/readings', {
    headers: { Authorization: 'Bearer c8b2f5fe21a414f3bccef6bc352c6472' },
  });
  return res.json();
}
export const MAX_RETRIES = 3;
