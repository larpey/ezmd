Keep real secrets out of git; this folder is ignored.
