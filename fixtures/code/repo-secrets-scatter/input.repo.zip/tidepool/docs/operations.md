# Operations

Connect to the staging replica:

```
psql postgres://ingest:db5ff3102adeede658@db.staging.example.invalid/tide
```

Local default (placeholder, keep visible): `postgres://ingest:changeme@localhost/tide`.
