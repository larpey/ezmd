# Operations

Connect to the staging replica:

```
psql postgres://ingest:bd2506d7e44fc2e388@db.staging.example.invalid/tide
```

Local default (placeholder, keep visible): `postgres://ingest:changeme@localhost/tide`.
